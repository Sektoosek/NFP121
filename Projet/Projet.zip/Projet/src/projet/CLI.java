package projet;

import java.util.HashMap;
import java.util.Map;

public class CLI {
	    private final Map<String, Option> options = new HashMap<>();
	    private final Map<String, Action> actions = new HashMap<>();

	    public void addOption(String name, String description, boolean hasValue) {
	        options.put(name, new Option(description, hasValue));
	    }

	    public void addAction(String name, Action action) {
	        actions.put(name, action);
	    }

	    public void parse(String[] args) throws CLIException {
	        int i = 0;
	        while (i < args.length) {
	            String arg = args[i];
	            if (!arg.startsWith("-")) {
	                throw new CLIException("Argument invalide : " + arg);
	            }
	            String name = arg.substring(1);
	            Option option = options.get(name);
	            if (option == null) {
	                throw new CLIException("Option inconnue : " + arg);
	            }
	            if (option.hasValue()) {
	                if (i == args.length - 1) {
	                    throw new CLIException("Argument Invalide");
	                }
	            }
	        }
	    }

		public Map<String, Option> getOptions() {
			return options;
		}

		public Map<String, Action> getActions() {
			return actions;
		}
	    

}
