import java.io.FileWriter;
import java.io.IOException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Attr;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class CLItoXML {

    public static void main(String[] args) throws ParserConfigurationException, IOException {

        CLI cli = new CLI();
        cli.addOption("alpha", 'A', "Valeur de alpha", true, 1);
        cli.addOption("indice", 'I', "Valeur de indice", true, 1);
        cli.addOption("pleine", 'P', "Mode matrice pleine", false, 0);
        cli.addOption("creuse", 'C', "Mode matrice creuse", false, 0);

        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        Document doc = dbf.newDocumentBuilder().newDocument();
        Element root = doc.createElement("cli");
        doc.appendChild(root);

        for (Option opt : cli.getOptions()) {
            Element arg = doc.createElement("argument");
            arg.appendChild(doc.createTextNode(opt.getDescription()));
            root.appendChild(arg);

            Attr accesAttr = doc.createAttribute("acces");
            accesAttr.setValue(String.valueOf(opt.getAccess()));
            arg.setAttributeNode(accesAttr);

            if (opt.getNbArgs() > 0) {
                Attr nbAttr = doc.createAttribute("nb");
                nbAttr.setValue(String.valueOf(opt.getNbArgs()));
                arg.setAttributeNode(nbAttr);
            }
        }

        TransformerFactory tf = TransformerFactory.newInstance();
        Transformer transformer = tf.newTransformer();
        DOMSource source = new DOMSource(doc);
        FileWriter writer = new FileWriter("cli.xml");
        StreamResult result = new StreamResult(writer);
        transformer.transform(source, result);
    }
}
