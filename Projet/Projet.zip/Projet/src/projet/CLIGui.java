package projet;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class CLIGui extends JFrame {
    
    private JPanel panel;
    private JButton creuseButton, pleineButton, plusButton;
    private JTextField argumentsTextField;
    
    public CLIGui() {
        super("Arguments de ligne de commande");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Création des composants graphiques
        panel = new JPanel();
        panel.setLayout(new GridLayout(1, 3));
        creuseButton = new JButton("Creuse (C)");
        pleineButton = new JButton("Pleine (P)");
        plusButton = new JButton("+");
        argumentsTextField = new JTextField(20);
        
        // Ajout des écouteurs d'événements
        creuseButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                argumentsTextField.setText(argumentsTextField.getText() + " -C");
            }
        });
        pleineButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                argumentsTextField.setText(argumentsTextField.getText() + " -P");
            }
        });
        plusButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String value = JOptionPane.showInputDialog("Entrez une valeur :");
                if (value != null && !value.isEmpty()) {
                    argumentsTextField.setText(argumentsTextField.getText() + " + " + value);
                }
            }
        });
        
        // Ajout des composants graphiques au panneau
        panel.add(creuseButton);
        panel.add(pleineButton);
        panel.add(plusButton);
        
        // Ajout du panneau et du champ de texte à la fenêtre
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(panel, BorderLayout.NORTH);
        getContentPane().add(argumentsTextField, BorderLayout.SOUTH);
        
        // Affichage de la fenêtre
        pack();
        setVisible(true);
    }
    
    public static void main(String[] args) {
        CLIGui gui = new CLIGui();
    }
    
}
