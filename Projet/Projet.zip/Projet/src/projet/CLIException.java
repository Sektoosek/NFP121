package projet;

public class CLIException extends Exception {
    public CLIException(String message) {
        super(message);
    }
}