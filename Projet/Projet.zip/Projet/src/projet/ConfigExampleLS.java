package projet;

import java.nio.file.Path;

public class ConfigExampleLS {

	public static class Configuration {
		public Path directory;
		public boolean showHiddenFiles = false;
		public boolean showDetails = false;
		public boolean recursive = false;
	}

	public static Configuration parseCommandLine(String... args) {
		Configuration config = new Configuration();

		for (int i = 0; i < args.length; i++) {
			String arg = args[i];
			switch (arg) {
			case "-a":
				config.showHiddenFiles = true;
				break;
			case "-l":
				config.showDetails = true;
				break;
			case "-R":
				config.recursive = true;
				break;
			default:
				config.directory = Path.of(arg);
			}
		}

		if (config.directory == null) {
			config.directory = Path.of(".");
		}

		return config;
	}
}



