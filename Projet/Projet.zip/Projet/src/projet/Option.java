package projet;
public class Option {
    private final String description;
    private final boolean hasValue;

    public Option(String description, boolean hasValue) {
        this.description = description;
        this.hasValue = hasValue;
    }

    public String getDescription() {
        return description;
    }

    public boolean hasValue() {
        return hasValue;
    }

	public char[] getAccess() {
		return null;
	}
}
