package projet;


public class PageRank {

    public static void main(String[] args) {
        CLI cli = new CLI();
        cli.addOption("K", "Valeur de l'indice à calculer", true);
        cli.addOption("E", "Valeur de la précision à atteindre", true);
        cli.addOption("A", "Valeur de alpha", true);
        cli.addOption("C", "Mode matrice creuse", false);
        cli.addOption("P", "Mode matrice pleine", false);

        try {
            cli.parse(args);
        } catch (CLIException e) {
            System.out.println(e.getMessage());
            return;
        }

        Configuration config = new Configuration();
        if (cli.hasOption("K")) {
            config.indice = Integer.parseInt(cli.getOptionValue("K"));
        }
        if (cli.hasOption("E")) {
            config.epsilon = Double.parseDouble(cli.getOptionValue("E"));
        }
        if (cli.hasOption("A")) {
            config.alpha = Double.parseDouble(cli.getOptionValue("A"));
        }
        if (cli.hasOption("C")) {
            config.mode = Mode.CREUSE;
        }
        if (cli.hasOption("P")) {
            config.mode = Mode.PLEINE;
        }

        // ... traitement du programme PageRank avec la configuration obtenue
    }
}

