package projet;

public enum Mode { PLEINE, CREUSE };
