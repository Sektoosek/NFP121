package projet;

public interface Action {
    void execute(String value) throws CLIException;
}



