package projet;

import java.lang.reflect.Field;

public class CLIOutils {
public static CLI fromClass(Class<?> configClass) {
    CLI cli = new CLI();
    Field[] fields = configClass.getDeclaredFields();
    for (Field field : fields) {
        field.setAccessible(true);
        Option option;
        if (field.getType() == boolean.class || field.getType() == Boolean.class) {
            option = new Option(Character.toLowerCase(field.getName().charAt(0)), "Positionner " + field.getName() + " à vrai");
            cli.addOption(option);
            option = new Option(Character.toUpperCase(field.getName().charAt(0)), "Positionner " + field.getName() + " à faux");
        } else {
            option = new Option(field.getName().charAt(0), "Valeur de " + field.getName());
        }
        cli.addOption(option);
    }
    return cli;
}
}